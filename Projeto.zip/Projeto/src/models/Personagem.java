package models;

public abstract class Personagem {
    private String nome;
    private int vida;
    private int forca;
    private int defesa;
    private int nivel;
    private int experiencia;

    public Personagem(String nome, int vida, int forca, int defesa) {
        this.nome = nome;
        this.vida = vida;
        this.forca = forca;
        this.defesa = defesa;
        this.nivel = 1;
        this.experiencia = 0;
    }

    public abstract void atacar(Personagem alvo);

    public void defender(int dano) {
        int danoRecebido = Math.max(dano - defesa, 0);
        vida -= danoRecebido;
        if (vida < 0) vida = 0;
    }

    public void ganharExperiencia(int pontos) {
        experiencia += pontos;
        if (experiencia >= 100) {
            subirNivel();
            experiencia = 0;
        }
    }

    private void subirNivel() {
        nivel++;
        forca += 5;
        defesa += 3;
        vida += 10;
    }

    public boolean estaVivo() {
        return vida > 0;
    }

    public String getNome() {
        return nome;
    }

    public int getVida() {
        return vida;
    }

    public int getForca() {
        return forca;
    }

    public int getDefesa() {
        return defesa;
    }

    public int getNivel() {
        return nivel;
    }
}
