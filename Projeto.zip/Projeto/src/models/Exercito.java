package models;

import java.util.ArrayList;
import java.util.List;

public class Exercito {
    private String nome;
    private List<Personagem> tropas;

    public Exercito(String nome) {
        this.nome = nome;
        this.tropas = new ArrayList<>();
    }

    public void adicionarPersonagem(Personagem personagem) {
        tropas.add(personagem);
    }

    public List<Personagem> getTropas() {
        return tropas;
    }

    public String getNome() {
        return nome;
    }

    public boolean estaDerrotado() {
        return tropas.stream().noneMatch(Personagem::estaVivo);
    }
}
