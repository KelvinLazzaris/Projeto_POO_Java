package models;

import javax.swing.JTextArea;

public class Batalha {
    private Exercito ex1;
    private Exercito ex2;

    public Batalha(Exercito ex1, Exercito ex2) {
        this.ex1 = ex1;
        this.ex2 = ex2;
    }

    public void iniciarBatalhaComLog(JTextArea logArea) {
        logArea.append("A batalha comecou entre " + ex1.getNome() + " e " + ex2.getNome() + "!\n");

        while (!ex1.estaDerrotado() && !ex2.estaDerrotado()) {
            logArea.append("\n--- Novo Turno ---\n");
            turno(ex1, ex2, logArea);
            if (!ex2.estaDerrotado()) turno(ex2, ex1, logArea);
        }

        String vencedor = ex1.estaDerrotado() ? ex2.getNome() : ex1.getNome();
        logArea.append("\nA batalha terminou! O vencedor e: " + vencedor + "!\n");
    }

    private void turno(Exercito atacante, Exercito defensor, JTextArea logArea) {
        for (Personagem p : atacante.getTropas()) {
            if (p.estaVivo()) {
                Personagem alvo = defensor.getTropas().stream().filter(Personagem::estaVivo).findFirst().orElse(null);
                if (alvo != null) {
                    logArea.append(p.getNome() + " atacou " + alvo.getNome() + "!\n");
                    p.atacar(alvo);
                    if (!alvo.estaVivo()) {
                        logArea.append(alvo.getNome() + " foi derrotado!\n");
                    }
                }
            }
        }
    }
}
