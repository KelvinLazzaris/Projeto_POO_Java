package ui;

import models.Exercito;
import models.Guerreiro;
import models.Batalha;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GameGUI extends JFrame {
    private Exercito ex1;
    private Exercito ex2;
    private JTextArea logArea;

    public GameGUI() {
        // Configuracao basica da janela
        setTitle("Jogo de Estrategia - Batalha de Exercitos");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Painel superior com botoes
        JPanel topPanel = new JPanel();
        JButton createArmyButton = new JButton("Criar Exercitos");
        JButton startBattleButton = new JButton("Iniciar Batalha");
        topPanel.add(createArmyButton);
        topPanel.add(startBattleButton);

        // Area de log (saida de eventos)
        logArea = new JTextArea();
        logArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(logArea);

        // Adicionar componentes a janela
        add(topPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        // Configuracoes dos botoes
        createArmyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                criarExercitos();
            }
        });

        startBattleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iniciarBatalha();
            }
        });
    }

    private void criarExercitos() {
        // Criando os exercitos com personagens predefinidos
        ex1 = new Exercito("Alianca");
        ex1.adicionarPersonagem(new Guerreiro("Guerreiro A1"));
        ex1.adicionarPersonagem(new Guerreiro("Guerreiro A2"));

        ex2 = new Exercito("Horda");
        ex2.adicionarPersonagem(new Guerreiro("Guerreiro H1"));
        ex2.adicionarPersonagem(new Guerreiro("Guerreiro H2"));

        // Atualizar o log
        logArea.append("Exercitos criados:\n");
        logArea.append("Exercito 1: " + ex1.getNome() + " com " + ex1.getTropas().size() + " personagens.\n");
        logArea.append("Exercito 2: " + ex2.getNome() + " com " + ex2.getTropas().size() + " personagens.\n");
    }

    private void iniciarBatalha() {
        if (ex1 == null || ex2 == null) {
            JOptionPane.showMessageDialog(this, "Por favor, crie os exercitos antes de iniciar a batalha!");
            return;
        }

        // Iniciar a batalha
        Batalha batalha = new Batalha(ex1, ex2);
        batalha.iniciarBatalhaComLog(logArea);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            GameGUI gameGUI = new GameGUI();
            gameGUI.setVisible(true);
        });
    }
}
