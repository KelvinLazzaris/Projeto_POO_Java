package models;

public class Mago extends Personagem {
    public Mago(String nome) {
        super(nome, 70, 25, 8); //! 25 de força
    }

    @Override
    public void atacar(Personagem alvo) {
        System.out.println(getNome() + " atacou " + alvo.getNome() + " causando " + getForca() + " de dano!");
        alvo.defender(getForca(), true); // Defesa não ativada no ataque padrão
    }
}
