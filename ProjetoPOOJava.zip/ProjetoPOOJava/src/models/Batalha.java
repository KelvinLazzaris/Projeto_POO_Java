package models;

import javax.swing.JTextArea;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public class Batalha {
    private Exercito ex1;
    private Exercito ex2;
    private Random random; // utilizado na defesa

    public Batalha(Exercito ex1, Exercito ex2) {
        this.ex1 = ex1;
        this.ex2 = ex2;
        this.random = new Random();
    }

    public void iniciarBatalhaComLog(JTextArea logArea) {
        logArea.append("A batalha começou entre " + ex1.getNome() + " e " + ex2.getNome() + "!\n");

        while (!ex1.estaDerrotado() && !ex2.estaDerrotado()) {
            logArea.append("\n--- Novo Turno ---\n");
            executarTurnoAlternado(logArea);
        }

        verificarVitoria(logArea);
    }

    private void executarTurnoAlternado(JTextArea logArea) {
        List<Personagem> vivosEx1 = ex1.getTropas().stream().filter(Personagem::estaVivo).collect(Collectors.toList());
        List<Personagem> vivosEx2 = ex2.getTropas().stream().filter(Personagem::estaVivo).collect(Collectors.toList());

        int maxAtaques = Math.max(vivosEx1.size(), vivosEx2.size());

        for (int i = 0; i < maxAtaques; i++) {
            // Ataque do exército 1
            if (i < vivosEx1.size() && !vivosEx2.isEmpty()) {
                Personagem atacante = vivosEx1.get(i);
                Personagem alvo = vivosEx2.get(0); // Atacar o primeiro personagem vivo do exército 2
                realizarAtaque(logArea, atacante, alvo);
            }

            // Ataque do exército 2
            if (i < vivosEx2.size() && !vivosEx1.isEmpty()) {
                Personagem atacante = vivosEx2.get(i);
                Personagem alvo = vivosEx1.get(0); // Atacar o primeiro personagem vivo do exército 1
                realizarAtaque(logArea, atacante, alvo);
            }
        }
    }

    private void realizarAtaque(JTextArea logArea, Personagem atacante, Personagem alvo) {
        logArea.append(atacante.getNome() + " atacou " + alvo.getNome() + " causando " + atacante.getForca() + " de dano!\n");
        boolean ativarDefesa = random.nextInt(100) < 30; // 30% de chance de defesa
        alvo.defender(atacante.getForca(), ativarDefesa);
        if (!alvo.estaVivo()) {
            logArea.append(alvo.getNome() + " foi derrotado!\n");
        }
    }

    private void verificarVitoria(JTextArea logArea) {
        if (ex1.estaDerrotado()) {
            logArea.append("\nA batalha terminou! O vencedor é: " + ex2.getNome() + "!\n");
        } else if (ex2.estaDerrotado()) {
            logArea.append("\nA batalha terminou! O vencedor é: " + ex1.getNome() + "!\n");
        }
    }
}
