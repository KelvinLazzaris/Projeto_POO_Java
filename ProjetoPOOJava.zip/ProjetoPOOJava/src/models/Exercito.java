package models;

import java.util.ArrayList;
import java.util.List;

public class Exercito {
    private String nome;
    private List<Personagem> tropas;
    private List<Item> itensDisponiveis;

    public Exercito(String nome) {
        this.nome = nome;
        this.tropas = new ArrayList<>();
        this.itensDisponiveis = new ArrayList<>();
    }

    public void adicionarPersonagem(Personagem personagem) {
        tropas.add(personagem);
    }

    public void adicionarItem(Item item) {
        itensDisponiveis.add(item);
    }

    public List<Personagem> getTropas() {
        return tropas;
    }

    public List<Item> getItensDisponiveis() {
        return itensDisponiveis;
    }

    public String getNome() {
        return nome;
    }

    public boolean estaDerrotado() {
        return tropas.stream().noneMatch(Personagem::estaVivo);
    }

    public void equiparItemAoPersonagem(int indexPersonagem, Item item) {
        Personagem personagem = tropas.get(indexPersonagem);
        personagem.usarItem(item);
        System.out.println(personagem.getNome() + " usou o item: " + item.getNome());
    }
    
}
