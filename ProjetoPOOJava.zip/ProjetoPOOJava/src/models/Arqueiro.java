package models;

public class Arqueiro extends Personagem {
    public Arqueiro(String nome) {
        super(nome, 80, 15, 10);
    }

    @Override
    public void atacar(Personagem alvo) {
        System.out.println(getNome() + " atacou " + alvo.getNome() + " causando " + getForca() + " de dano!");
        alvo.defender(getForca(), true); // Defesa não ativada no ataque padrão
    }
}
