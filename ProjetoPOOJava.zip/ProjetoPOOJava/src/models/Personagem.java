package models;

/* import javax.swing.JTextArea; */

public abstract class Personagem {
    private String nome;
    private int vida;
    private int forca;
    private int defesa;
    private int nivel;
    private int experiencia;

    public Personagem(String nome, int vida, int forca, int defesa) {
        this.nome = nome;
        this.vida = vida;
        this.forca = forca;
        this.defesa = defesa;
        this.nivel = 1;
        this.experiencia = 0;
    }

    public String getNome() {
        return nome;
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = Math.max(0, vida);
    }

    public int getForca() {
        return forca;
    }

    public void setForca(int forca) {
        this.forca = forca;
    }

    public int getDefesa() {
        return defesa;
    }

    public boolean estaVivo() {
        return vida > 0;
    }

    public void usarItem(Item item) {
        item.aplicarEfeito(this); // Aplica o efeito do item ao personagem
    }

    public abstract void atacar(Personagem alvo);

    public void defender(int dano, boolean ativarDefesa) {
        if (ativarDefesa) {
            if (dano > defesa) {
                int danoFinal = dano - defesa;
                setVida(vida - danoFinal);
                System.out.println(nome + " defendeu, mas sofreu " + danoFinal + " de dano!\n");
            } else {
                System.out.println(nome + " defendeu com sucesso e não sofreu dano!\n");
            }
        } else {
            setVida(vida - dano);
            System.out.println(nome + " não defendeu e sofreu " + dano + " de dano!\n");
        }
    }

}