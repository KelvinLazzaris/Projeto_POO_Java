package models;

public class Pocao extends Item {
    private int cura;

    public Pocao(String nome, int cura) {
        super(nome, "Poção");
        this.cura = cura;
    }

    @Override
    public void aplicarEfeito(Personagem personagem) {
        personagem.setVida(personagem.getVida() + cura);
        System.out.println(personagem.getNome() + " usou a poção " + getNome() + " e recuperou " + cura + " de vida!");
    }
}
