package models;

public class Guerreiro extends Personagem {
    public Guerreiro(String nome) {
        super(nome, 100, 20, 15);
    }

    @Override
    public void atacar(Personagem alvo) {
        System.out.println(getNome() + " atacou " + alvo.getNome() + " causando " + getForca() + " de dano!");
        alvo.defender(getForca(), true);
    }
}
    