package models;

public class Arma extends Item {
    private int danoExtra;

    public Arma(String nome, int danoExtra) {
        super(nome, "Arma");
        this.danoExtra = danoExtra;
    }

    @Override
    public void aplicarEfeito(Personagem personagem) {
        personagem.setForca(personagem.getForca() + danoExtra);
        System.out.println(personagem.getNome() + " equipou a arma " + getNome() + " e ganhou " + danoExtra + " de força!");
    }
}
