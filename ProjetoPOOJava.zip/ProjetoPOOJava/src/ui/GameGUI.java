/* package ui;

import models.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GameGUI extends JFrame {
    private Exercito ex1;
    private Exercito ex2;
    private JTextArea logArea;

    public GameGUI() {
        setTitle("Jogo de Estratégia - Batalha de Exércitos");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel();
        JButton createArmyButton = new JButton("Criar Exércitos");
        JButton startBattleButton = new JButton("Iniciar Batalha");
        JButton statsButton = new JButton("Exibir Estatísticas");

        topPanel.add(createArmyButton);
        topPanel.add(startBattleButton);
        topPanel.add(statsButton);

        logArea = new JTextArea();
        logArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(logArea);

        add(topPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        createArmyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                criarExercitos();
            }
        });

        startBattleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iniciarBatalha();
            }
        });

        statsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exibirEstatisticas();
            }
        });
    }

    private void criarExercitos() {
        logArea.setText("");

        ex1 = configurarExercito("Aliança");
        ex2 = configurarExercito("Horda");

        logArea.append("Exércitos criados:\n");
        logArea.append("Exército 1 (" + ex1.getNome() + "): " + ex1.getTropas().size() + " personagens.\n");
        logArea.append("Exército 2 (" + ex2.getNome() + "): " + ex2.getTropas().size() + " personagens.\n");
    }

    private Exercito configurarExercito(String nomeExercito) {
        Exercito exercito = new Exercito(nomeExercito);

        // Solicitar o número de guerreiros, arqueiros e magos
        int numGuerreiros = solicitarQuantidade("Quantos guerreiros o exército " + nomeExercito + " deve ter?");
        int numArqueiros = solicitarQuantidade("Quantos arqueiros o exército " + nomeExercito + " deve ter?");
        int numMagos = solicitarQuantidade("Quantos magos o exército " + nomeExercito + " deve ter?");

        // Adicionar personagens ao exército
        for (int i = 0; i < numGuerreiros; i++) {
            exercito.adicionarPersonagem(new Guerreiro("Guerreiro " + nomeExercito + " " + (i + 1)));
        }
        for (int i = 0; i < numArqueiros; i++) {
            exercito.adicionarPersonagem(new Arqueiro("Arqueiro " + nomeExercito + " " + (i + 1)));
        }
        for (int i = 0; i < numMagos; i++) {
            exercito.adicionarPersonagem(new Mago("Mago " + nomeExercito + " " + (i + 1)));
        }

        return exercito;
    }

    private int solicitarQuantidade(String mensagem) {
        while (true) {
            String input = JOptionPane.showInputDialog(this, mensagem, "Configuração do Exército", JOptionPane.QUESTION_MESSAGE);
            try {
                int quantidade = Integer.parseInt(input);
                if (quantidade >= 0) {
                    return quantidade;
                } else {
                    JOptionPane.showMessageDialog(this, "Por favor, insira um número maior ou igual a zero.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Entrada inválida. Por favor, insira um número.");
            }
        }
    }

    private void iniciarBatalha() {
        if (ex1 == null || ex2 == null) {
            JOptionPane.showMessageDialog(this, "Por favor, crie os exércitos antes de iniciar a batalha!");
            return;
        }

        Batalha batalha = new Batalha(ex1, ex2);
        batalha.iniciarBatalhaComLog(logArea);
    }

    private void exibirEstatisticas() {
        if (ex1 == null || ex2 == null) {
            JOptionPane.showMessageDialog(this, "Por favor, crie os exércitos antes de exibir as estatísticas!");
            return;
        }

        StringBuilder stats = new StringBuilder();
        stats.append("Estatísticas do Exército 1 (" + ex1.getNome() + "):\n");
        for (Personagem p : ex1.getTropas()) {
            stats.append(" - " + p.getNome() + ": Vida = " + p.getVida() + ", Força = " + p.getForca() + ", Defesa = " + p.getDefesa() + "\n");
        }
        stats.append("\nEstatísticas do Exército 2 (" + ex2.getNome() + "):\n");
        for (Personagem p : ex2.getTropas()) {
            stats.append(" - " + p.getNome() + ": Vida = " + p.getVida() + ", Força = " + p.getForca() + ", Defesa = " + p.getDefesa() + "\n");
        }

        JOptionPane.showMessageDialog(this, stats.toString(), "Estatísticas dos Exércitos", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            GameGUI gameGUI = new GameGUI();
            gameGUI.setVisible(true);
        });
    }
}*/


package ui;

import models.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GameGUI extends JFrame {
    private Exercito ex1;
    private Exercito ex2;
    private JTextArea logArea;

    public GameGUI() {
        setTitle("Jogo de Estratégia - Batalha de Exércitos");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel();
        JButton createArmyButton = new JButton("Criar Exércitos");
        JButton startBattleButton = new JButton("Iniciar Batalha");
        JButton statsButton = new JButton("Exibir Estatísticas");
        JButton useItemButton = new JButton("Usar Item");

        topPanel.add(createArmyButton);
        topPanel.add(startBattleButton);
        topPanel.add(statsButton);
        topPanel.add(useItemButton);

        logArea = new JTextArea();
        logArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(logArea);

        add(topPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        createArmyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                criarExercitos();
            }
        });

        startBattleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iniciarBatalha();
            }
        });

        statsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exibirEstatisticas();
            }
        });

        useItemButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                usarItem();
            }
        });
    }

    private void criarExercitos() {
        logArea.setText("");

        ex1 = configurarExercito("Aliança");
        ex2 = configurarExercito("Horda");

        // Adicionando itens aos exércitos
        ex1.adicionarItem(new Arma("Espada Lendária", 10));
        ex1.adicionarItem(new Pocao("Poção de Cura", 20));
        ex2.adicionarItem(new Arma("Machado de Guerra", 15));
        ex2.adicionarItem(new Pocao("Poção de Energia", 15));

        logArea.append("Exércitos criados:\n");
        logArea.append("Exército 1 (" + ex1.getNome() + "): " + ex1.getTropas().size() + " personagens.\n");
        logArea.append("Exército 2 (" + ex2.getNome() + "): " + ex2.getTropas().size() + " personagens.\n");
    }

    private Exercito configurarExercito(String nomeExercito) {
        Exercito exercito = new Exercito(nomeExercito);

        // Solicitar o número de guerreiros, arqueiros e magos
        int numGuerreiros = solicitarQuantidade("Quantos guerreiros o exército " + nomeExercito + " deve ter?");
        int numArqueiros = solicitarQuantidade("Quantos arqueiros o exército " + nomeExercito + " deve ter?");
        int numMagos = solicitarQuantidade("Quantos magos o exército " + nomeExercito + " deve ter?");

        // Adicionar personagens ao exército
        for (int i = 0; i < numGuerreiros; i++) {
            exercito.adicionarPersonagem(new Guerreiro("Guerreiro " + nomeExercito + " " + (i + 1)));
        }
        for (int i = 0; i < numArqueiros; i++) {
            exercito.adicionarPersonagem(new Arqueiro("Arqueiro " + nomeExercito + " " + (i + 1)));
        }
        for (int i = 0; i < numMagos; i++) {
            exercito.adicionarPersonagem(new Mago("Mago " + nomeExercito + " " + (i + 1)));
        }

        return exercito;
    }

    private int solicitarQuantidade(String mensagem) {
        while (true) {
            String input = JOptionPane.showInputDialog(this, mensagem, "Configuração do Exército", JOptionPane.QUESTION_MESSAGE);
            try {
                int quantidade = Integer.parseInt(input);
                if (quantidade >= 0) {
                    return quantidade;
                } else {
                    JOptionPane.showMessageDialog(this, "Por favor, insira um número maior ou igual a zero.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Entrada inválida. Por favor, insira um número.");
            }
        }
    }

    private void iniciarBatalha() {
        if (ex1 == null || ex2 == null) {
            JOptionPane.showMessageDialog(this, "Por favor, crie os exércitos antes de iniciar a batalha!");
            return;
        }

        Batalha batalha = new Batalha(ex1, ex2);
        batalha.iniciarBatalhaComLog(logArea);
    }

    private void exibirEstatisticas() {
        if (ex1 == null || ex2 == null) {
            JOptionPane.showMessageDialog(this, "Por favor, crie os exércitos antes de exibir as estatísticas!");
            return;
        }

        StringBuilder stats = new StringBuilder();
        stats.append("Estatísticas do Exército 1 (" + ex1.getNome() + "):\n");
        for (Personagem p : ex1.getTropas()) {
            stats.append(" - " + p.getNome() + ": Vida = " + p.getVida() + ", Força = " + p.getForca() + ", Defesa = " + p.getDefesa() + "\n");
        }
        stats.append("\nEstatísticas do Exército 2 (" + ex2.getNome() + "):\n");
        for (Personagem p : ex2.getTropas()) {
            stats.append(" - " + p.getNome() + ": Vida = " + p.getVida() + ", Força = " + p.getForca() + ", Defesa = " + p.getDefesa() + "\n");
        }

        JOptionPane.showMessageDialog(this, stats.toString(), "Estatísticas dos Exércitos", JOptionPane.INFORMATION_MESSAGE);
    }

    private void usarItem() {
        if (ex1 == null || ex2 == null) {
            JOptionPane.showMessageDialog(this, "Por favor, crie os exércitos antes de usar itens!");
            return;
        }

        String[] opcoesExercito = {ex1.getNome(), ex2.getNome()};
        String exercitoEscolhido = (String) JOptionPane.showInputDialog(
                this,
                "Escolha o exército:",
                "Usar Item",
                JOptionPane.QUESTION_MESSAGE,
                null,
                opcoesExercito,
                opcoesExercito[0]
        );

        Exercito exercito = exercitoEscolhido.equals(ex1.getNome()) ? ex1 : ex2;

        if (exercito.getItensDisponiveis().isEmpty()) {
            JOptionPane.showMessageDialog(this, "O exército " + exercito.getNome() + " não possui itens disponíveis!");
            return;
        }

        String[] personagens = exercito.getTropas().stream().map(Personagem::getNome).toArray(String[]::new);
        String personagemEscolhido = (String) JOptionPane.showInputDialog(
                this,
                "Escolha o personagem para usar o item:",
                "Usar Item",
                JOptionPane.QUESTION_MESSAGE,
                null,
                personagens,
                personagens[0]
        );

        String[] itens = exercito.getItensDisponiveis().stream().map(Item::getNome).toArray(String[]::new);
        String itemEscolhido = (String) JOptionPane.showInputDialog(
                this,
                "Escolha o item para usar:",
                "Usar Item",
                JOptionPane.QUESTION_MESSAGE,
                null,
                itens,
                itens[0]
        );

        Personagem personagem = exercito.getTropas().stream()
                .filter(p -> p.getNome().equals(personagemEscolhido))
                .findFirst()
                .orElse(null);

        Item item = exercito.getItensDisponiveis().stream()
                .filter(i -> i.getNome().equals(itemEscolhido))
                .findFirst()
                .orElse(null);

        if (personagem != null && item != null) {
            personagem.usarItem(item);
            exercito.getItensDisponiveis().remove(item);
            logArea.append(personagem.getNome() + " usou o item " + item.getNome() + "!\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            GameGUI gameGUI = new GameGUI();
            gameGUI.setVisible(true);
        });
    }
}
